from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


PLUGIN_ROOT = Path(__file__).resolve().parents[1]
HOOK = PLUGIN_ROOT / "hooks" / "dev_flow_hook.py"
WINDOWS_HOOK = PLUGIN_ROOT / "hooks" / "dev_flow_hook.cmd"
HOOKS_JSON = PLUGIN_ROOT / "hooks" / "hooks.json"


class DevFlowHookTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.data_dir = Path(self.temporary.name) / "plugin-data"
        self.data_dir.mkdir()
        self.cwd = Path(self.temporary.name) / "repository"
        self.cwd.mkdir()

    def write_scope(self, *, include: list[Path] | None = None, exclude: list[Path] | None = None) -> None:
        scope = {
            "mode": "allowlist" if include else "all",
            "include": [str(path) for path in include or []],
            "exclude": [str(path) for path in exclude or []],
        }
        (self.data_dir / "config.json").write_text(
            json.dumps({"schema_version": 1, "scope": scope}), encoding="utf-8"
        )

    def invoke(
        self,
        payload: dict,
        *,
        cwd: Path | None = None,
        include_plugin_root: bool = True,
        include_plugin_data: bool = True,
        env: dict[str, str] | None = None,
    ) -> tuple[str, str]:
        invocation = dict(payload)
        invocation.setdefault("cwd", str(cwd or self.cwd))
        environment = os.environ.copy()
        if include_plugin_root:
            environment["PLUGIN_ROOT"] = str(PLUGIN_ROOT)
        else:
            environment.pop("PLUGIN_ROOT", None)
        if include_plugin_data:
            environment["PLUGIN_DATA"] = str(self.data_dir)
        else:
            environment.pop("PLUGIN_DATA", None)
        environment.update(env or {})
        completed = subprocess.run(
            [sys.executable, str(HOOK)],
            input=json.dumps(invocation),
            text=True,
            capture_output=True,
            check=False,
            env=environment,
        )
        self.assertEqual(completed.returncode, 0, completed.stderr)
        return completed.stdout, completed.stderr

    def activate(self, stage: str, **extra: object) -> Path:
        values = {
            "route": {"value": "direct", "reason": "bounded change"},
            "pending_gate": "workspace-approval" if stage == "ROUTE_APPROVED" else None,
            "next_action": "prepare the managed worktree",
        }
        values.update(extra)
        return self.write_core_state(
            "TASK-42",
            stage,
            **values,
        )

    def write_core_state(
        self,
        task_id: str,
        stage: str,
        *,
        updated_at: str = "2026-07-21T12:00:00Z",
        repository: dict | None = None,
        **extra: object,
    ) -> Path:
        task_dir = self.data_dir / "tasks" / task_id
        task_dir.mkdir(parents=True, exist_ok=True)
        state = {
            "schema_version": 1,
            "task_id": task_id,
            "status": stage,
            "updated_at": updated_at,
            "route": "standard",
            "repositories": [repository or {"id": "repo", "path": str(self.cwd)}],
            "approvals": {},
            "workspace": {},
        }
        state.update(extra)
        state_file = task_dir / "state.json"
        state_file.write_text(json.dumps(state), encoding="utf-8")
        return state_file

    def assert_denied(self, command: str, *, cwd: Path | None = None) -> str:
        stdout, stderr = self.invoke(
            {
                "hook_event_name": "PreToolUse",
                "tool_name": "Bash",
                "tool_input": {"command": command},
            },
            cwd=cwd,
        )
        self.assertEqual(stderr, "")
        output = json.loads(stdout)
        specific = output["hookSpecificOutput"]
        self.assertEqual(specific["hookEventName"], "PreToolUse")
        self.assertEqual(specific["permissionDecision"], "deny")
        self.assertTrue(specific["permissionDecisionReason"])
        return specific["permissionDecisionReason"]

    def test_default_plugin_hook_discovery_and_commands(self) -> None:
        document = json.loads(HOOKS_JSON.read_text(encoding="utf-8"))
        hooks = document["hooks"]
        self.assertEqual(
            set(hooks), {"SessionStart", "UserPromptSubmit", "PreToolUse"}
        )
        self.assertNotIn("Stop", hooks)
        self.assertIn("Bash", hooks["PreToolUse"][0]["matcher"])
        for groups in hooks.values():
            for group in groups:
                for handler in group["hooks"]:
                    self.assertIn("$PLUGIN_ROOT/hooks/dev_flow_hook.py", handler["command"])
                    self.assertIn("commandWindows", handler)
                    self.assertIn(
                        "%PLUGIN_ROOT%\\hooks\\dev_flow_hook.cmd",
                        handler["commandWindows"],
                    )
                    self.assertNotIn("python3", handler["commandWindows"].lower())
                    self.assertNotIn("~", handler["command"])
                    self.assertNotIn("~", handler["commandWindows"])
        shim = WINDOWS_HOOK.read_text(encoding="utf-8")
        self.assertIn("setlocal DisableDelayedExpansion", shim)
        self.assertIn("py -3", shim)
        for version in ("3.14", "3.13", "3.12", "3.11", "3.10", "3.9"):
            self.assertIn(version, shim)
        self.assertIn("python", shim)
        self.assertIn("(3, 9) <= sys.version_info[:2] < (3, 15)", shim)
        self.assertIn('"%PLUGIN_ROOT%\\hooks\\dev_flow_hook.py"', shim)
        self.assertIn("%*", shim)
        self.assertIn("exit /b %errorlevel%", shim)

    def test_session_start_injects_active_task_checkpoint(self) -> None:
        self.activate("ROUTE_APPROVED")
        stdout, stderr = self.invoke(
            {"hook_event_name": "SessionStart", "source": "resume"}
        )
        self.assertEqual(stderr, "")
        output = json.loads(stdout)
        specific = output["hookSpecificOutput"]
        self.assertEqual(specific["hookEventName"], "SessionStart")
        context = specific["additionalContext"]
        self.assertIn("Active task: TASK-42", context)
        self.assertIn("Stage: ROUTE_APPROVED", context)
        self.assertIn("Route: direct", context)
        self.assertIn("Pending gate: workspace-approval", context)
        self.assertIn("Next action: prepare the managed worktree", context)
        self.assertIn(f"Data directory: {self.data_dir.resolve()}", context)
        self.assertIn(f"Controller: {PLUGIN_ROOT / 'scripts' / 'dev_flow.py'}", context)
        self.assertIn(f"Interpreter: {sys.executable}", context)
        self.assertIn(f"--data-dir {self.data_dir.resolve()}", context)
        self.assertIn("show --task TASK-42", context)
        self.assertIn("Every controller call must explicitly include", context)
        self.assertNotIn("$PLUGIN_ROOT", context)

    def test_data_dir_argument_replaces_missing_plugin_data(self) -> None:
        # Global registrations run without either plugin variable and pass an
        # absolute hook path plus --data-dir.
        environment = os.environ.copy()
        environment.pop("PLUGIN_DATA", None)
        environment.pop("PLUGIN_ROOT", None)
        completed = subprocess.run(
            [sys.executable, str(HOOK), "--data-dir", str(self.data_dir)],
            input=json.dumps(
                {"hook_event_name": "SessionStart", "cwd": str(self.cwd)}
            ),
            text=True,
            capture_output=True,
            check=False,
            env=environment,
        )
        self.assertEqual(completed.returncode, 0, completed.stderr)
        context = json.loads(completed.stdout)["hookSpecificOutput"]["additionalContext"]
        self.assertIn("Dev Flow controller bootstrap:", context)
        self.assertIn(f"Controller: {PLUGIN_ROOT / 'scripts' / 'dev_flow.py'}", context)
        self.assertIn(f"Data directory: {self.data_dir.resolve()}", context)

    def test_data_dir_argument_outranks_inherited_plugin_data(self) -> None:
        other = Path(self.temporary.name) / "stale-plugin-data"
        other.mkdir()
        completed = subprocess.run(
            [sys.executable, str(HOOK), f"--data-dir={self.data_dir}"],
            input=json.dumps(
                {"hook_event_name": "SessionStart", "cwd": str(self.cwd)}
            ),
            text=True,
            capture_output=True,
            check=False,
            env={
                **os.environ,
                "PLUGIN_ROOT": str(PLUGIN_ROOT),
                "PLUGIN_DATA": str(other),
            },
        )
        self.assertEqual(completed.returncode, 0, completed.stderr)
        context = json.loads(completed.stdout)["hookSpecificOutput"]["additionalContext"]
        self.assertIn(f"Data directory: {self.data_dir.resolve()}", context)

    def test_hook_protocol_is_utf8_bytes_with_one_lf_and_accepts_crlf(self) -> None:
        unicode_data = Path(self.temporary.name) / "插件 data ü"
        unicode_data.mkdir()
        unicode_cwd = Path(self.temporary.name) / "仓库 ü"
        unicode_cwd.mkdir()
        payload = {
            "hook_event_name": "SessionStart",
            "source": "startup",
            "cwd": str(unicode_cwd),
        }
        completed = subprocess.run(
            [sys.executable, str(HOOK)],
            input=json.dumps(payload, ensure_ascii=False).encode("utf-8") + b"\r\n",
            capture_output=True,
            check=False,
            env={
                **os.environ,
                "PLUGIN_ROOT": str(PLUGIN_ROOT),
                "PLUGIN_DATA": str(unicode_data),
            },
        )
        self.assertEqual(completed.returncode, 0, completed.stderr)
        self.assertEqual(completed.stderr, b"")
        self.assertTrue(completed.stdout.endswith(b"\n"))
        self.assertFalse(completed.stdout.endswith(b"\r\n"))
        self.assertEqual(completed.stdout.count(b"\n"), 1)
        output = json.loads(completed.stdout.decode("utf-8"))
        context = output["hookSpecificOutput"]["additionalContext"]
        self.assertIn(str(unicode_data.resolve()), context)
        self.assertIn("插件", context)

    def test_malformed_utf8_protocol_input_fails_open_silently(self) -> None:
        completed = subprocess.run(
            [sys.executable, str(HOOK)],
            input=b"\xff\xfe\r\n",
            capture_output=True,
            check=False,
            env={
                **os.environ,
                "PLUGIN_ROOT": str(PLUGIN_ROOT),
                "PLUGIN_DATA": str(self.data_dir),
            },
        )
        self.assertEqual(completed.returncode, 0)
        self.assertEqual(completed.stdout, b"")
        self.assertEqual(completed.stderr, b"")

    def test_actual_packaged_hook_command_for_native_platform(self) -> None:
        special_root = (
            Path(self.temporary.name) / "插件 root ! & (hooks) $literal"
        )
        special_data = (
            Path(self.temporary.name) / "数据 state ! & (flow) $literal"
        )
        special_cwd = Path(self.temporary.name) / "仓库 work & (tree)"
        (special_root / "hooks").mkdir(parents=True)
        (special_root / "scripts").mkdir()
        special_data.mkdir()
        special_cwd.mkdir()
        shutil.copy2(HOOK, special_root / "hooks" / HOOK.name)
        shutil.copy2(WINDOWS_HOOK, special_root / "hooks" / WINDOWS_HOOK.name)
        shutil.copy2(
            PLUGIN_ROOT / "scripts" / "dev_flow.py",
            special_root / "scripts" / "dev_flow.py",
        )

        task_dir = special_data / "tasks" / "PACKAGED-1"
        task_dir.mkdir(parents=True)
        (task_dir / "state.json").write_text(
            json.dumps(
                {
                    "schema_version": 1,
                    "task_id": "PACKAGED-1",
                    "status": "INTAKE",
                    "updated_at": "2026-07-24T01:00:00Z",
                    "route": None,
                    "repositories": [
                        {"id": "repo", "path": str(special_cwd)}
                    ],
                    "approvals": {},
                    "workspace": {},
                },
                ensure_ascii=False,
            ),
            encoding="utf-8",
        )
        payloads = {
            "SessionStart": {
                "hook_event_name": "SessionStart",
                "source": "startup",
                "cwd": str(special_cwd),
            },
            "UserPromptSubmit": {
                "hook_event_name": "UserPromptSubmit",
                "prompt": "继续",
                "cwd": str(special_cwd),
            },
            "PreToolUse": {
                "hook_event_name": "PreToolUse",
                "tool_name": "Bash",
                "tool_input": {"command": "git pull --ff-only"},
                "cwd": str(special_cwd),
            },
        }
        command_key = "commandWindows" if os.name == "nt" else "command"
        environment = {
            **os.environ,
            "PLUGIN_ROOT": str(special_root),
            "PLUGIN_DATA": str(special_data),
        }
        document = json.loads(HOOKS_JSON.read_text(encoding="utf-8"))
        for event, groups in document["hooks"].items():
            for group in groups:
                for handler in group["hooks"]:
                    command = handler[command_key]
                    with self.subTest(event=event, command=command_key):
                        completed = subprocess.run(
                            command,
                            shell=True,
                            input=(
                                json.dumps(
                                    payloads[event], ensure_ascii=False
                                ).encode("utf-8")
                                + b"\r\n"
                            ),
                            capture_output=True,
                            check=False,
                            env=environment,
                            timeout=20,
                        )
                        self.assertEqual(
                            completed.returncode, 0, completed.stderr
                        )
                        self.assertEqual(completed.stderr, b"")
                        self.assertTrue(completed.stdout.endswith(b"\n"))
                        self.assertFalse(completed.stdout.endswith(b"\r\n"))
                        output = json.loads(completed.stdout.decode("utf-8"))
                        specific = output["hookSpecificOutput"]
                        self.assertEqual(specific["hookEventName"], event)
                        if event == "PreToolUse":
                            self.assertEqual(
                                specific["permissionDecision"], "deny"
                            )
                            reason = specific["permissionDecisionReason"]
                            self.assertIn(str(special_root), reason)
                            self.assertIn(str(special_data), reason)
                        else:
                            context = specific["additionalContext"]
                            self.assertIn(str(special_root), context)
                            self.assertIn(str(special_data), context)
                            interpreter = next(
                                line.removeprefix("- Interpreter: ")
                                for line in context.splitlines()
                                if line.startswith("- Interpreter: ")
                            )
                            command_line = next(
                                line
                                for line in context.splitlines()
                                if line.startswith(("- Bootstrap command: ", "- Resume command: "))
                            )
                            self.assertIn(interpreter, command_line)

    @unittest.skipUnless(
        os.name == "nt", "requires native cmd.exe launcher resolution"
    )
    def test_windows_launcher_falls_back_when_py_is_unsupported(self) -> None:
        launcher_dir = Path(self.temporary.name) / "fake launchers"
        launcher_dir.mkdir()
        launch_log = Path(self.temporary.name) / "launcher.log"
        (launcher_dir / "py.cmd").write_text(
            "\n".join(
                (
                    "@echo off",
                    "setlocal DisableDelayedExpansion",
                    '>>"%DEV_FLOW_LAUNCH_LOG%" echo py-unsupported',
                    "exit /b 1",
                    "",
                )
            ),
            encoding="utf-8",
        )
        (launcher_dir / "python.cmd").write_text(
            "\n".join(
                (
                    "@echo off",
                    "setlocal DisableDelayedExpansion",
                    '>>"%DEV_FLOW_LAUNCH_LOG%" echo python-supported',
                    f'"{sys.executable}" %*',
                    "exit /b %errorlevel%",
                    "",
                )
            ),
            encoding="utf-8",
        )
        document = json.loads(HOOKS_JSON.read_text(encoding="utf-8"))
        command = document["hooks"]["SessionStart"][0]["hooks"][0][
            "commandWindows"
        ]
        completed = subprocess.run(
            command,
            shell=True,
            input=json.dumps(
                {
                    "hook_event_name": "SessionStart",
                    "source": "startup",
                    "cwd": str(self.cwd),
                }
            ).encode("utf-8"),
            capture_output=True,
            check=False,
            env={
                **os.environ,
                "PATH": str(launcher_dir)
                + os.pathsep
                + os.environ.get("PATH", ""),
                "DEV_FLOW_LAUNCH_LOG": str(launch_log),
                "PLUGIN_ROOT": str(PLUGIN_ROOT),
                "PLUGIN_DATA": str(self.data_dir),
            },
            timeout=20,
        )
        self.assertEqual(completed.returncode, 0, completed.stderr)
        self.assertEqual(completed.stderr, b"")
        self.assertIn("Dev Flow controller bootstrap", completed.stdout.decode("utf-8"))
        self.assertEqual(
            launch_log.read_text(encoding="utf-8").splitlines(),
            [
                *(["py-unsupported"] * 7),
                "python-supported",
                "python-supported",
            ],
        )

    @unittest.skipUnless(
        os.name == "nt", "requires native cmd.exe launcher resolution"
    )
    def test_windows_launcher_finds_supported_explicit_py_version(self) -> None:
        launcher_dir = Path(self.temporary.name) / "versioned launchers"
        launcher_dir.mkdir()
        launch_log = Path(self.temporary.name) / "versioned-launcher.log"
        supported_version = (
            f"{sys.version_info.major}.{sys.version_info.minor}"
        )
        (launcher_dir / "py.cmd").write_text(
            "\n".join(
                (
                    "@echo off",
                    "setlocal DisableDelayedExpansion",
                    '>>"%DEV_FLOW_LAUNCH_LOG%" echo py-%~1',
                    f'if not "%~1"=="-{supported_version}" exit /b 1',
                    'if "%~2"=="-c" "%DEV_FLOW_REAL_PYTHON%" -c "%~3"',
                    'if not "%~2"=="-c" "%DEV_FLOW_REAL_PYTHON%" "%~2"',
                    "exit /b %errorlevel%",
                    "",
                )
            ),
            encoding="utf-8",
        )
        (launcher_dir / "python.cmd").write_text(
            "@echo off\nexit /b 1\n",
            encoding="utf-8",
        )
        document = json.loads(HOOKS_JSON.read_text(encoding="utf-8"))
        command = document["hooks"]["SessionStart"][0]["hooks"][0][
            "commandWindows"
        ]
        completed = subprocess.run(
            command,
            shell=True,
            input=json.dumps(
                {
                    "hook_event_name": "SessionStart",
                    "source": "startup",
                    "cwd": str(self.cwd),
                }
            ).encode("utf-8"),
            capture_output=True,
            check=False,
            env={
                **os.environ,
                "PATH": str(launcher_dir)
                + os.pathsep
                + os.environ.get("PATH", ""),
                "DEV_FLOW_LAUNCH_LOG": str(launch_log),
                "DEV_FLOW_REAL_PYTHON": sys.executable,
                "PLUGIN_ROOT": str(PLUGIN_ROOT),
                "PLUGIN_DATA": str(self.data_dir),
            },
            timeout=20,
        )
        self.assertEqual(completed.returncode, 0, completed.stderr)
        self.assertEqual(completed.stderr, b"")
        self.assertIn(
            "Dev Flow controller bootstrap",
            completed.stdout.decode("utf-8"),
        )
        self.assertEqual(
            launch_log.read_text(encoding="utf-8").splitlines(),
            [
                "py--3",
                *[
                    f"py--3.{minor}"
                    for minor in range(14, sys.version_info.minor - 1, -1)
                ],
                f"py--{supported_version}",
            ],
        )

    def test_user_prompt_submit_uses_its_own_output_event_name(self) -> None:
        self.activate("PLANNING", pending_gate=None, next_action="write the plan")
        stdout, _ = self.invoke(
            {"hook_event_name": "UserPromptSubmit", "prompt": "continue"}
        )
        output = json.loads(stdout)
        specific = output["hookSpecificOutput"]
        self.assertEqual(specific["hookEventName"], "UserPromptSubmit")
        self.assertIn("Next action: write the plan", specific["additionalContext"])

    def test_context_selects_baseline_index_explicitly_before_workspace(self) -> None:
        self.activate(
            "INDEXED",
            repository={
                "id": "service",
                "path": str(self.cwd),
                "index": {"index_id": "task-service-baseline"},
            },
        )
        stdout, _ = self.invoke(
            {"hook_event_name": "SessionStart", "source": "resume"}
        )
        context = json.loads(stdout)["hookSpecificOutput"]["additionalContext"]
        self.assertIn(
            "codebase-memory selection: explicit project parameter; never automatic",
            context,
        )
        self.assertIn("Active index role: baseline", context)
        self.assertIn("Active index projects: service=task-service-baseline", context)

    def test_context_requires_workspace_index_after_workspace_creation(self) -> None:
        self.activate(
            "WORKSPACE_READY",
            repository={
                "id": "service",
                "path": str(self.cwd),
                "index": {"index_id": "task-service-baseline"},
            },
            next_action=None,
        )
        stdout, _ = self.invoke(
            {"hook_event_name": "UserPromptSubmit", "prompt": "continue"}
        )
        context = json.loads(stdout)["hookSpecificOutput"]["additionalContext"]
        self.assertIn("Active index role: workspace", context)
        self.assertIn("Active index projects: service=MISSING", context)
        self.assertIn(
            "Next action: create or refresh every workspace index, then create the implementation plan",
            context,
        )

    def test_context_selects_current_workspace_project_and_blocked_origin(self) -> None:
        repository = {
            "id": "service",
            "path": str(self.cwd),
            "index": {"index_id": "task-service-baseline"},
            "workspace_index": {"index_id": "task-service-workspace-r0"},
        }
        state_file = self.activate("IMPLEMENTING", repository=repository)
        stdout, _ = self.invoke(
            {"hook_event_name": "SessionStart", "source": "resume"}
        )
        context = json.loads(stdout)["hookSpecificOutput"]["additionalContext"]
        self.assertIn("Active index role: workspace", context)
        self.assertIn(
            "Active index projects: service=task-service-workspace-r0", context
        )

        task = json.loads(state_file.read_text(encoding="utf-8"))
        task["status"] = "BLOCKED"
        task["blocked"] = {"from_status": "INDEXED", "reason": "example"}
        state_file.write_text(json.dumps(task), encoding="utf-8")
        stdout, _ = self.invoke(
            {"hook_event_name": "UserPromptSubmit", "prompt": "resume"}
        )
        context = json.loads(stdout)["hookSpecificOutput"]["additionalContext"]
        self.assertIn("Active index role: baseline", context)
        self.assertIn("Active index projects: service=task-service-baseline", context)

    def test_context_uses_controller_gate_keys_and_stage_actions(self) -> None:
        state_file = self.activate(
            "PREFLIGHTED", pending_gate=None, next_action=None, approvals={}
        )
        stdout, _ = self.invoke(
            {"hook_event_name": "SessionStart", "source": "resume"}
        )
        context = json.loads(stdout)["hookSpecificOutput"]["additionalContext"]
        self.assertIn("Pending gate: baseline fetch/materialization approval", context)

        task = json.loads(state_file.read_text(encoding="utf-8"))
        task["status"] = "REVIEWING"
        task["approvals"] = {}
        state_file.write_text(json.dumps(task), encoding="utf-8")
        stdout, _ = self.invoke(
            {"hook_event_name": "UserPromptSubmit", "prompt": "continue"}
        )
        context = json.loads(stdout)["hookSpecificOutput"]["additionalContext"]
        self.assertIn("Pending gate: review approval", context)
        self.assertIn("Next action: approve the review and then finalize", context)

        task["status"] = "FINALIZING"
        state_file.write_text(json.dumps(task), encoding="utf-8")
        stdout, _ = self.invoke(
            {"hook_event_name": "SessionStart", "source": "resume"}
        )
        context = json.loads(stdout)["hookSpecificOutput"]["additionalContext"]
        self.assertIn("Pending gate: none", context)

    def test_current_core_layout_selects_latest_nonterminal_task_for_cwd(self) -> None:
        self.write_core_state(
            "TASK-OLD", "PLANNING", updated_at="2026-07-21T10:00:00Z"
        )
        self.write_core_state(
            "TASK-NEW",
            "IMPLEMENTING",
            updated_at="2026-07-21T11:00:00Z",
            next_action="run focused tests",
        )
        self.write_core_state(
            "TASK-DONE", "DONE", updated_at="2026-07-21T12:00:00Z"
        )
        stdout, _ = self.invoke(
            {"hook_event_name": "SessionStart", "source": "resume"}
        )
        context = json.loads(stdout)["hookSpecificOutput"]["additionalContext"]
        self.assertIn("Active task: TASK-NEW", context)
        self.assertIn("Stage: IMPLEMENTING", context)
        self.assertNotIn("TASK-DONE", context)

    def test_current_core_layout_matches_managed_workspace_path(self) -> None:
        source = Path(self.temporary.name) / "source-repository"
        source.mkdir()
        self.write_core_state(
            "TASK-WORKSPACE",
            "WORKSPACE_READY",
            repository={
                "id": "repo",
                "path": str(source),
                "canonical_path": str(source.resolve()),
                "workspace": {
                    "path": str(self.cwd),
                    "branch": "dev-flow/TASK-WORKSPACE",
                },
            },
        )
        stdout, _ = self.invoke(
            {"hook_event_name": "UserPromptSubmit", "prompt": "continue"}
        )
        context = json.loads(stdout)["hookSpecificOutput"]["additionalContext"]
        self.assertIn("Active task: TASK-WORKSPACE", context)

    def test_analysis_workspace_is_active_but_remains_write_guarded(self) -> None:
        source = Path(self.temporary.name) / "source-repository"
        source.mkdir()
        managed = Path(self.temporary.name) / "managed-workspace"
        managed.mkdir()
        self.write_core_state(
            "TASK-ANALYSIS",
            "WORKSPACE_READY",
            repository={
                "id": "repo",
                "path": str(source),
                "canonical_path": str(source.resolve()),
                "analysis_workspace": {
                    "path": str(self.cwd),
                    "base_sha": "a" * 40,
                },
                "workspace": {
                    "path": str(managed),
                    "branch": "codex/TASK-ANALYSIS",
                    "ready": True,
                },
            },
        )
        stdout, _ = self.invoke(
            {
                "hook_event_name": "PreToolUse",
                "tool_name": "apply_patch",
                "tool_input": {"command": "*** Begin Patch"},
            }
        )
        specific = json.loads(stdout)["hookSpecificOutput"]
        self.assertEqual(specific["permissionDecision"], "deny")
        self.assertIn("analysis workspaces", specific["permissionDecisionReason"])

    def test_context_events_diagnose_missing_plugin_environment(self) -> None:
        for event, extra in (
            ("SessionStart", {"source": "startup"}),
            ("UserPromptSubmit", {"prompt": "hello"}),
        ):
            for missing in ("PLUGIN_ROOT", "PLUGIN_DATA"):
                with self.subTest(event=event, missing=missing):
                    stdout, stderr = self.invoke(
                        {"hook_event_name": event, **extra},
                        include_plugin_root=missing != "PLUGIN_ROOT",
                        include_plugin_data=missing != "PLUGIN_DATA",
                    )
                    self.assertEqual(stderr, "")
                    specific = json.loads(stdout)["hookSpecificOutput"]
                    self.assertEqual(specific["hookEventName"], event)
                    context = specific["additionalContext"]
                    self.assertIn("Dev Flow hook diagnostic", context)
                    self.assertIn(f"{missing} is missing or empty", context)
                    self.assertIn("No controller command was constructed", context)
                    self.assertNotIn("Bootstrap command:", context)
                    self.assertNotIn("Resume command:", context)

    def test_bundled_environment_rejects_relative_blank_and_invalid_roots(
        self,
    ) -> None:
        missing_root = Path(self.temporary.name) / "missing-plugin"
        cases = (
            ({"PLUGIN_ROOT": "."}, "PLUGIN_ROOT must be an absolute path"),
            ({"PLUGIN_DATA": "."}, "PLUGIN_DATA must be an absolute path"),
            ({"PLUGIN_ROOT": "   "}, "PLUGIN_ROOT is missing or empty"),
            ({"PLUGIN_DATA": "\t"}, "PLUGIN_DATA is missing or empty"),
            (
                {"PLUGIN_ROOT": str(missing_root)},
                "PLUGIN_ROOT does not contain scripts/dev_flow.py",
            ),
        )
        for environment, expected in cases:
            with self.subTest(environment=environment):
                stdout, stderr = self.invoke(
                    {"hook_event_name": "SessionStart", "source": "startup"},
                    env=environment,
                )
                self.assertEqual(stderr, "")
                context = json.loads(stdout)["hookSpecificOutput"][
                    "additionalContext"
                ]
                self.assertIn(expected, context)
                self.assertIn("No controller command was constructed", context)
                self.assertNotIn("Bootstrap command:", context)

    def test_pre_tool_use_missing_environment_is_diagnostic_not_denial(self) -> None:
        for missing in ("PLUGIN_ROOT", "PLUGIN_DATA"):
            with self.subTest(missing=missing):
                stdout, stderr = self.invoke(
                    {
                        "hook_event_name": "PreToolUse",
                        "tool_name": "Bash",
                        "tool_input": {"command": "git reset --hard HEAD"},
                    },
                    include_plugin_root=missing != "PLUGIN_ROOT",
                    include_plugin_data=missing != "PLUGIN_DATA",
                )
                self.assertEqual(stderr, "")
                specific = json.loads(stdout)["hookSpecificOutput"]
                self.assertEqual(specific["hookEventName"], "PreToolUse")
                self.assertNotIn("permissionDecision", specific)
                context = specific["additionalContext"]
                self.assertIn(f"{missing} is missing or empty", context)
                self.assertIn("no workflow state was mutated", context)

    def test_destructive_and_workflow_bypass_commands_are_denied(self) -> None:
        self.activate("INTAKE")
        commands = (
            "git push --force origin feature",
            "git push --force-with-lease origin feature",
            "git reset --hard HEAD~1",
            "git clean -fd",
            "git pull --ff-only",
            "git switch feature/TASK-42",
            "git checkout -b feature/TASK-42",
            "git worktree add ../task-worktree -b feature/TASK-42",
            "cd subdir && git push origin main",
            "bash -lc 'git reset --hard HEAD'",
        )
        for command in commands:
            with self.subTest(command=command):
                self.assert_denied(command)
        reason = self.assert_denied("git pull --ff-only")
        self.assertIn(str(PLUGIN_ROOT / "scripts" / "dev_flow.py"), reason)
        self.assertIn(f"--data-dir {self.data_dir.resolve()}", reason)
        self.assertNotIn("$PLUGIN_ROOT", reason)

    def test_protected_git_decision_is_equivalent_across_executables_and_wrappers(
        self,
    ) -> None:
        self.activate("INTAKE")
        commands = (
            "git reset --hard HEAD",
            "git.exe reset --hard HEAD",
            "/usr/bin/git reset --hard HEAD",
            '"C:/Program Files/Git/cmd/git.exe" reset --hard HEAD',
            r'"C:\Program Files\Git\cmd\git.exe" reset --hard HEAD',
            r"C:\Git\cmd\git.exe reset --hard HEAD",
            r'"\\server\share\Git\cmd\git.exe" reset --hard HEAD',
            r"/opt/Git\ Tools/bin/git reset --hard HEAD",
            "sh -c 'git reset --hard HEAD'",
            "bash -lc 'echo safe && git reset --hard HEAD'",
            'cmd.exe /d /s /c "echo safe && git.exe reset --hard HEAD"',
            r"cmd.exe /c C:\Program^ Files\Git\cmd\git.exe reset --hard HEAD",
            (
                'cmd.exe /d /s /c ""C:\\Program Files\\Git\\cmd\\git.exe" '
                'reset --hard HEAD"'
            ),
            (
                'powershell.exe -NoProfile -Command '
                '"Write-Output safe; git.exe reset --hard HEAD"'
            ),
            (
                "pwsh -Command "
                "'& \"C:\\Program Files\\Git\\cmd\\git.exe\" reset --hard HEAD'"
            ),
            (
                "pwsh -Command "
                r"'& C:\Program` Files\Git\cmd\git.exe reset --hard HEAD'"
            ),
        )
        expected: str | None = None
        for command in commands:
            with self.subTest(command=command):
                reason = self.assert_denied(command)
                self.assertIn("git reset --hard", reason)
                if expected is None:
                    expected = reason
                self.assertEqual(reason, expected)

    def test_benign_git_decision_is_equivalent_across_wrappers(self) -> None:
        self.activate("IMPLEMENTING")
        commands = (
            "git status --short",
            "git.exe status --short",
            '"C:/Program Files/Git/cmd/git.exe" status --short',
            r'"C:\Program Files\Git\cmd\git.exe" status --short',
            r'"\\server\share\Git\cmd\git.exe" status --short',
            r"/opt/Git\ Tools/bin/git status --short",
            "sh -c 'git status --short'",
            "bash -lc 'echo safe && git status --short'",
            "bash -lc 'git status -- \\$literal'",
            "bash -lc \"git status -- '\\$literal'\"",
            'cmd.exe /d /s /c "echo safe && git.exe status --short"',
            r"cmd.exe /c C:\Program^ Files\Git\cmd\git.exe status --short",
            (
                'cmd.exe /d /s /c ""C:\\Program Files\\Git\\cmd\\git.exe" '
                'status --short"'
            ),
            (
                'powershell.exe -NoProfile -Command '
                '"Write-Output safe; git.exe status --short"'
            ),
            (
                "pwsh -Command "
                "'& \"C:\\Program Files\\Git\\cmd\\git.exe\" status --short'"
            ),
            'pwsh -Command "git status -- \'$literal\'"',
            "pwsh -Command 'git status -- `$literal'",
            (
                "pwsh -Command "
                r"'& C:\Program` Files\Git\cmd\git.exe status --short'"
            ),
        )
        for command in commands:
            with self.subTest(command=command):
                stdout, stderr = self.invoke(
                    {
                        "hook_event_name": "PreToolUse",
                        "tool_name": "Bash",
                        "tool_input": {"command": command},
                    }
                )
                self.assertEqual(stdout, "")
                self.assertEqual(stderr, "")

    def test_ambiguous_recognized_wrappers_are_denied_with_diagnostics(self) -> None:
        self.activate("INTAKE")
        commands = (
            "bash -lc '$GIT reset --hard HEAD'",
            'cmd.exe /c "%GIT% reset --hard HEAD"',
            "powershell.exe -Command '& $git reset --hard HEAD'",
            "pwsh -EncodedCommand Z2l0IHJlc2V0IC0taGFyZA==",
            "bash -lc 'echo $DYNAMIC_COMMAND'",
            "bash workflow-script.sh",
            'cmd.exe /c "echo %DYNAMIC_COMMAND%"',
            "cmd.exe /k git reset --hard HEAD",
            "pwsh -Command 'Write-Output $dynamicCommand'",
            'powershell.exe -Command "& (Get-Command git) reset --hard HEAD"',
            'cmd.exe /c "git reset --hard',
            'powershell.exe -Command "git reset --hard',
        )
        for command in commands:
            with self.subTest(command=command):
                reason = self.assert_denied(command)
                self.assertIn("could not be inspected safely", reason)

    def test_direct_push_and_commit_on_protected_branch_are_denied(self) -> None:
        subprocess.run(
            ["git", "init", "-q", str(self.cwd)],
            check=True,
            capture_output=True,
            text=True,
        )
        subprocess.run(
            ["git", "-C", str(self.cwd), "symbolic-ref", "HEAD", "refs/heads/main"],
            check=True,
            capture_output=True,
            text=True,
        )
        self.activate("INTAKE")
        self.assertIn("protected branch", self.assert_denied("git commit -m change"))
        self.assertIn("Direct pushes", self.assert_denied("git push origin main"))
        self.assertIn("Direct pushes", self.assert_denied("git push"))

        outer = Path(self.temporary.name) / "outer"
        outer.mkdir()
        stdout, _ = self.invoke(
            {
                "hook_event_name": "PreToolUse",
                "tool_name": "Bash",
                "tool_input": {
                    "command": "git commit -m change",
                    "workdir": str(self.cwd),
                },
            },
            cwd=outer,
        )
        self.assertEqual(
            json.loads(stdout)["hookSpecificOutput"]["permissionDecision"], "deny"
        )

    def test_recorded_default_branch_is_also_protected(self) -> None:
        subprocess.run(
            ["git", "init", "-q", str(self.cwd)],
            check=True,
            capture_output=True,
            text=True,
        )
        subprocess.run(
            ["git", "-C", str(self.cwd), "symbolic-ref", "HEAD", "refs/heads/develop"],
            check=True,
            capture_output=True,
            text=True,
        )
        self.write_core_state(
            "TASK-DEVELOP",
            "WORKSPACE_READY",
            repository={
                "id": "repo",
                "path": str(self.cwd),
                "preflight": {"base_branch": "develop"},
            },
        )
        reason = self.assert_denied("git commit -m change")
        self.assertIn("develop", reason)

    def test_read_only_git_commands_and_feature_push_are_not_blocked(self) -> None:
        self.activate("IMPLEMENTING")
        commands = (
            "git status --short",
            "git diff --stat",
            "git log -1 --oneline",
            "git show HEAD:README.md",
            "git branch --show-current",
            "echo git push --force origin main",
            "git push origin feature/TASK-42",
            "python3 scripts/dev_flow.py workspace prepare TASK-42",
        )
        for command in commands:
            with self.subTest(command=command):
                stdout, stderr = self.invoke(
                    {
                        "hook_event_name": "PreToolUse",
                        "tool_name": "Bash",
                        "tool_input": {"command": command},
                    }
                )
                self.assertEqual(stdout, "")
                self.assertEqual(stderr, "")

    def test_file_writes_are_denied_until_workspace_ready(self) -> None:
        task_file = self.activate("ROUTE_APPROVED")
        for tool_name in ("apply_patch", "Write"):
            with self.subTest(tool_name=tool_name):
                stdout, _ = self.invoke(
                    {
                        "hook_event_name": "PreToolUse",
                        "tool_name": tool_name,
                        "tool_input": {"command": "*** Begin Patch"},
                    }
                )
                specific = json.loads(stdout)["hookSpecificOutput"]
                self.assertEqual(specific["permissionDecision"], "deny")
                self.assertIn("source repositories", specific["permissionDecisionReason"])

        task = json.loads(task_file.read_text(encoding="utf-8"))
        task["status"] = "WORKSPACE_READY"
        managed = Path(self.temporary.name) / "managed-workspace"
        managed.mkdir()
        task["repositories"][0]["workspace"] = {
            "path": str(managed),
            "branch": "codex/TASK-42",
            "ready": True,
        }
        task_file.write_text(json.dumps(task), encoding="utf-8")

        stdout, _ = self.invoke(
            {
                "hook_event_name": "PreToolUse",
                "tool_name": "apply_patch",
                "tool_input": {"command": "*** Begin Patch"},
            }
        )
        reason = json.loads(stdout)["hookSpecificOutput"]["permissionDecisionReason"]
        self.assertIn("source repositories", reason)

        stdout, stderr = self.invoke(
            {
                "hook_event_name": "PreToolUse",
                "tool_name": "apply_patch",
                "tool_input": {"command": "*** Begin Patch"},
            },
            cwd=managed,
        )
        self.assertEqual(stdout, "")
        self.assertEqual(stderr, "")

        stdout, stderr = self.invoke(
            {
                "hook_event_name": "PreToolUse",
                "tool_name": "apply_patch",
                "tool_input": {
                    "command": "*** Begin Patch",
                    "workdir": str(managed),
                },
            }
        )
        self.assertEqual(stdout, "")
        self.assertEqual(stderr, "")

    def test_explicit_write_targets_must_all_be_in_ready_workspaces(self) -> None:
        managed = Path(self.temporary.name) / "managed-workspace"
        managed.mkdir()
        state_file = self.activate("WORKSPACE_READY")
        task = json.loads(state_file.read_text(encoding="utf-8"))
        task["repositories"][0]["workspace"] = {
            "path": str(managed),
            "branch": "codex/TASK-42",
            "ready": True,
        }
        state_file.write_text(json.dumps(task), encoding="utf-8")

        stdout, stderr = self.invoke(
            {
                "hook_event_name": "PreToolUse",
                "tool_name": "Write",
                "tool_input": {"file_path": str(managed / "new.py")},
            }
        )
        self.assertEqual(stdout, "")
        self.assertEqual(stderr, "")

        mixed_patch = "\n".join(
            (
                "*** Begin Patch",
                "*** Update File: managed.py",
                f"*** Delete File: {self.cwd / 'source.py'}",
                "*** End Patch",
            )
        )
        stdout, _ = self.invoke(
            {
                "hook_event_name": "PreToolUse",
                "tool_name": "apply_patch",
                "tool_input": {"command": mixed_patch, "workdir": str(managed)},
            }
        )
        reason = json.loads(stdout)["hookSpecificOutput"]["permissionDecisionReason"]
        self.assertIn("source repositories", reason)

        # Free-form apply_patch input may be exposed under `patch` rather than
        # `command`; it must receive the same multi-target path validation.
        stdout, _ = self.invoke(
            {
                "hook_event_name": "PreToolUse",
                "tool_name": "apply_patch",
                "tool_input": {"patch": mixed_patch, "workdir": str(managed)},
            }
        )
        reason = json.loads(stdout)["hookSpecificOutput"]["permissionDecisionReason"]
        self.assertIn("source repositories", reason)

    def test_indexed_task_can_write_only_its_artifacts_directory(self) -> None:
        self.activate("INDEXED")
        artifacts = self.data_dir / "tasks" / "TASK-42" / "artifacts"
        artifacts.mkdir()

        for tool_input, invocation_cwd in (
            ({"file_path": str(artifacts / "impact.md")}, self.cwd),
            (
                {
                    "command": "*** Begin Patch\n*** Add File: impact.md\n*** End Patch",
                    "workdir": str(artifacts),
                },
                self.cwd,
            ),
            ({"file_path": str(artifacts / "from-artifact-cwd.md")}, artifacts),
        ):
            with self.subTest(tool_input=tool_input, cwd=invocation_cwd):
                stdout, stderr = self.invoke(
                    {
                        "hook_event_name": "PreToolUse",
                        "tool_name": "apply_patch"
                        if "command" in tool_input
                        else "Write",
                        "tool_input": tool_input,
                    },
                    cwd=invocation_cwd,
                )
                self.assertEqual(stdout, "")
                self.assertEqual(stderr, "")

        forbidden_targets = (
            self.data_dir / "tasks" / "TASK-42" / "state.json",
            self.data_dir / "tasks" / "TASK-42" / "events.jsonl",
            self.data_dir / "tasks" / "TASK-42" / "reviews" / "review.md",
            self.data_dir / "tasks" / "OTHER" / "artifacts" / "impact.md",
        )
        for target in forbidden_targets:
            with self.subTest(target=target):
                stdout, _ = self.invoke(
                    {
                        "hook_event_name": "PreToolUse",
                        "tool_name": "Write",
                        "tool_input": {"file_path": str(target)},
                    }
                )
                specific = json.loads(stdout)["hookSpecificOutput"]
                self.assertEqual(specific["permissionDecision"], "deny")

        stdout, _ = self.invoke(
            {
                "hook_event_name": "PreToolUse",
                "tool_name": "Write",
                "tool_input": {"file_path": str(self.cwd / "business.py")},
            }
        )
        reason = json.loads(stdout)["hookSpecificOutput"]["permissionDecisionReason"]
        self.assertIn("source repositories", reason)

        state_file = self.data_dir / "tasks" / "TASK-42" / "state.json"
        task = json.loads(state_file.read_text(encoding="utf-8"))
        task["status"] = "BLOCKED"
        state_file.write_text(json.dumps(task), encoding="utf-8")
        stdout, _ = self.invoke(
            {
                "hook_event_name": "PreToolUse",
                "tool_name": "Write",
                "tool_input": {"file_path": str(artifacts / "blocked.md")},
            }
        )
        specific = json.loads(stdout)["hookSpecificOutput"]
        self.assertEqual(specific["permissionDecision"], "deny")
        self.assertIn("BLOCKED", specific["permissionDecisionReason"])

    def test_lite_task_checkpoint_names_flow_gate_and_no_index_role(self) -> None:
        self.write_core_state(
            "LITE-7",
            "PREFLIGHTED",
            flow="lite",
            route=None,
            next_action=None,
        )
        stdout, stderr = self.invoke(
            {"hook_event_name": "SessionStart", "source": "resume"}
        )
        self.assertEqual(stderr, "")
        context = json.loads(stdout)["hookSpecificOutput"]["additionalContext"]
        self.assertIn("Active task: LITE-7", context)
        self.assertIn("Flow: lite (in place, no managed worktree)", context)
        self.assertIn("Pending gate: lite in-place approval", context)
        self.assertIn("Active index role: none", context)
        self.assertIn(
            "Next action: present the in-place scope and obtain the lite approval",
            context,
        )

    def test_lite_task_source_writes_follow_the_stage(self) -> None:
        state_file = self.write_core_state(
            "LITE-7",
            "PREFLIGHTED",
            flow="lite",
        )
        artifacts = self.data_dir / "tasks" / "LITE-7" / "artifacts"
        artifacts.mkdir(parents=True)

        # Before implementation, only the artifacts directory is writable.
        stdout, _ = self.invoke(
            {
                "hook_event_name": "PreToolUse",
                "tool_name": "Write",
                "tool_input": {"file_path": str(self.cwd / "bug.py")},
            }
        )
        specific = json.loads(stdout)["hookSpecificOutput"]
        self.assertEqual(specific["permissionDecision"], "deny")
        stdout, stderr = self.invoke(
            {
                "hook_event_name": "PreToolUse",
                "tool_name": "Write",
                "tool_input": {"file_path": str(artifacts / "scope.md")},
            }
        )
        self.assertEqual(stdout, "")
        self.assertEqual(stderr, "")

        # During implementation the source checkout itself is the workspace.
        task = json.loads(state_file.read_text(encoding="utf-8"))
        task["status"] = "IMPLEMENTING"
        state_file.write_text(json.dumps(task), encoding="utf-8")
        stdout, stderr = self.invoke(
            {
                "hook_event_name": "PreToolUse",
                "tool_name": "Write",
                "tool_input": {"file_path": str(self.cwd / "bug.py")},
            }
        )
        self.assertEqual(stdout, "")
        self.assertEqual(stderr, "")

        # A blocked lite task blocks writes again.
        task["status"] = "BLOCKED"
        state_file.write_text(json.dumps(task), encoding="utf-8")
        stdout, _ = self.invoke(
            {
                "hook_event_name": "PreToolUse",
                "tool_name": "Write",
                "tool_input": {"file_path": str(self.cwd / "bug.py")},
            }
        )
        specific = json.loads(stdout)["hookSpecificOutput"]
        self.assertEqual(specific["permissionDecision"], "deny")
        self.assertIn("BLOCKED", specific["permissionDecisionReason"])

    def test_unified_exec_cmd_alias_is_guarded(self) -> None:
        self.activate("INTAKE")
        stdout, _ = self.invoke(
            {
                "hook_event_name": "PreToolUse",
                "tool_name": "Bash",
                "tool_input": {"cmd": "git reset --hard HEAD"},
            }
        )
        self.assertEqual(
            json.loads(stdout)["hookSpecificOutput"]["permissionDecision"], "deny"
        )

    def test_shell_policy_is_silent_without_an_active_task(self) -> None:
        for command in (
            "git pull --ff-only",
            "git switch feature/unrelated",
            "git reset --hard HEAD",
            "git clean -fd",
            "git push --force origin feature/unrelated",
        ):
            with self.subTest(command=command):
                stdout, stderr = self.invoke(
                    {
                        "hook_event_name": "PreToolUse",
                        "tool_name": "Bash",
                        "tool_input": {"command": command},
                    }
                )
                self.assertEqual(stdout, "")
                self.assertEqual(stderr, "")

    def test_file_write_without_active_task_is_not_blocked(self) -> None:
        stdout, stderr = self.invoke(
            {
                "hook_event_name": "PreToolUse",
                "tool_name": "apply_patch",
                "tool_input": {"command": "*** Begin Patch"},
            }
        )
        self.assertEqual(stdout, "")
        self.assertEqual(stderr, "")

    def test_bootstrap_is_silent_outside_the_configured_scope(self) -> None:
        included = Path(self.temporary.name) / "included"
        included.mkdir()
        self.write_scope(include=[included])
        for event in ("SessionStart", "UserPromptSubmit"):
            with self.subTest(event=event):
                stdout, stderr = self.invoke({"hook_event_name": event})
                self.assertEqual(stdout, "")
                self.assertEqual(stderr, "")
        stdout, _ = self.invoke({"hook_event_name": "SessionStart"}, cwd=included)
        self.assertIn(
            "Dev Flow controller bootstrap",
            json.loads(stdout)["hookSpecificOutput"]["additionalContext"],
        )

    def test_scope_accepts_subdirectories_and_the_environment_override(self) -> None:
        nested = self.cwd / "packages" / "api"
        nested.mkdir(parents=True)
        excluded = self.cwd / "vendor"
        excluded.mkdir()
        self.write_scope(include=[self.cwd], exclude=[excluded])
        stdout, _ = self.invoke({"hook_event_name": "SessionStart"}, cwd=nested)
        self.assertIn("Dev Flow controller bootstrap", stdout)
        stdout, _ = self.invoke({"hook_event_name": "SessionStart"}, cwd=excluded)
        self.assertEqual(stdout, "")
        # The environment override replaces the stored included directories.
        outside = Path(self.temporary.name) / "outside"
        outside.mkdir()
        override = {"DEV_FLOW_SCOPE": str(outside)}
        stdout, _ = self.invoke(
            {"hook_event_name": "SessionStart"}, cwd=outside, env=override
        )
        self.assertIn("Dev Flow controller bootstrap", stdout)
        stdout, _ = self.invoke(
            {"hook_event_name": "SessionStart"}, cwd=nested, env=override
        )
        self.assertEqual(stdout, "")

    def test_active_task_keeps_hooks_enabled_outside_the_scope(self) -> None:
        self.activate(
            "IMPLEMENTING",
            repository={
                "id": "repo",
                "path": str(self.cwd),
                "preflight": {"branch": "main"},
            },
        )
        included = Path(self.temporary.name) / "included"
        included.mkdir()
        self.write_scope(include=[included])
        stdout, _ = self.invoke({"hook_event_name": "SessionStart"})
        context = json.loads(stdout)["hookSpecificOutput"]["additionalContext"]
        self.assertIn("Active task: TASK-42", context)
        self.assertIn("Directory scope: outside the configured scope", context)
        self.assertIn(
            "Direct commits on protected branch",
            self.assert_denied("git commit -m 'out of scope'"),
        )

    def test_in_scope_checkpoint_omits_the_scope_notice(self) -> None:
        self.activate("IMPLEMENTING")
        self.write_scope(include=[self.cwd])
        stdout, _ = self.invoke({"hook_event_name": "SessionStart"})
        context = json.loads(stdout)["hookSpecificOutput"]["additionalContext"]
        self.assertIn("Active task: TASK-42", context)
        self.assertNotIn("Directory scope", context)

    def test_unreadable_scope_configuration_keeps_the_hook_active(self) -> None:
        (self.data_dir / "config.json").write_text("{ not json", encoding="utf-8")
        stdout, stderr = self.invoke({"hook_event_name": "SessionStart"})
        self.assertEqual(stderr, "")
        self.assertIn("Dev Flow controller bootstrap", stdout)


if __name__ == "__main__":
    unittest.main()
